document.getElementById("tripForm").addEventListener("submit", function(e){
  e.preventDefault();
  const name = this.elements.name.value.trim();
  const trip = this.elements.trip.value;
  const note = document.getElementById("formNote");
  note.textContent = `Дякуємо, ${name}! Заявку${trip ? " на " + trip : ""} підготовлено. Додай свій Telegram/Instagram у контактах, щоб менеджер міг зв’язатися з тобою.`;
  this.reset();
});