# Woman's Corp.

Luxury landing page for Woman's Corp. women's travel community.

## GitHub Pages

1. Створи новий GitHub repository, наприклад `womans-corp`.
2. Завантаж `index.html`, `style.css` та `script.js`.
3. Відкрий **Settings → Pages**.
4. У **Build and deployment** вибери **Deploy from a branch**.
5. Branch: `main`, folder: `/ (root)`.
6. Збережи. Через кілька хвилин сайт буде доступний за адресою GitHub Pages.

### Що змінити перед публікацією
- Замінити demo-фотографії Unsplash на власні фото Woman's Corp.
- Додати реальні Instagram та Telegram посилання.
- Підключити форму до SendPulse / Telegram / CRM, якщо потрібно отримувати заявки.
